---
name: AURESCENT
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#39393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#d2c5b1'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#9b8f7d'
  outline-variant: '#4e4637'
  surface-tint: '#f0bf5c'
  primary: '#f0bf5c'
  on-primary: '#412d00'
  primary-container: '#c89b3c'
  on-primary-container: '#4b3500'
  inverse-primary: '#7b5900'
  secondary: '#e7c26d'
  on-secondary: '#3f2e00'
  secondary-container: '#694e00'
  on-secondary-container: '#e7c26c'
  tertiary: '#c9c6c0'
  on-tertiary: '#31302c'
  tertiary-container: '#a5a29c'
  on-tertiary-container: '#3a3934'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea4'
  primary-fixed-dim: '#f0bf5c'
  on-primary-fixed: '#261900'
  on-primary-fixed-variant: '#5d4200'
  secondary-fixed: '#ffdf9a'
  secondary-fixed-dim: '#e7c26d'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#e6e2db'
  tertiary-fixed-dim: '#c9c6c0'
  on-tertiary-fixed: '#1c1c18'
  on-tertiary-fixed-variant: '#484742'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  display-lg:
    fontFamily: Cinzel
    fontSize: 84px
    fontWeight: '400'
    lineHeight: 92px
    letterSpacing: 0.05em
  display-lg-mobile:
    fontFamily: Cinzel
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: 0.05em
  headline-lg:
    fontFamily: Cinzel
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: 0.03em
  headline-lg-mobile:
    fontFamily: Cinzel
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 38px
    letterSpacing: 0.03em
  quote-italic:
    fontFamily: Cormorant Garamond
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: Poppins
    fontSize: 18px
    fontWeight: '300'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Poppins
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Poppins
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.2em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1440px
  gutter: 32px
  margin-mobile: 20px
  margin-desktop: 80px
  section-gap: 160px
---

## Brand & Style
The design system embodies ultra-high-end luxury through a cinematic, editorial lens. It aims to evoke an emotional response of exclusivity, heritage, and sensory indulgence. The visual direction is anchored in **Minimalism** with a heavy influence of **Glassmorphism**, creating a digital experience that feels as much like a physical boutique as it does a gallery.

The aesthetic prioritizes generous whitespace to allow product photography—rich in texture, liquid, and shadow—to breathe. Interaction is deliberate and rhythmic, mirroring the slow, intentional pace of haute couture. The target audience is a discerning global elite who values craftsmanship over conspicuous consumption.

## Colors
The palette is rooted in a deep, near-infinite **Obsidian (#0F0F10)**, providing a high-contrast foundation for metallic accents. **Rich Gold (#C89B3C)** serves as the primary brand color, used sparingly for critical calls to action and iconography to maintain its premium feel. 

**Champagne (#E5C06B)** is utilized for secondary highlights and gradients, while **Ivory (#F6F2EB)** provides a sophisticated alternative to pure white for primary text and high-visibility labels, softening the visual impact on dark backgrounds.

## Typography
The typography system uses a tri-font hierarchy to balance heritage with modern utility. 
- **Cinzel** is used for monumental headings. Its Roman proportions convey a sense of timelessness and "Aurescent" authority. 
- **Cormorant Garamond** is reserved for pull-quotes, sub-titles, or French-inspired descriptions to add a layer of literary sophistication and warmth. 
- **Poppins** acts as the functional workhorse, providing a clean, geometric counterpoint for body copy and UI elements, ensuring legibility at smaller scales.

Use wide letter-spacing on all uppercase labels and display text to reinforce the luxury editorial feel.

## Layout & Spacing
This design system utilizes a **fixed grid** approach for desktop (12 columns) and a fluid grid for mobile (4 columns). The spacing rhythm is intentionally "slow," meaning larger-than-standard gaps between sections (160px+) to ensure no two elements compete for attention.

- **Desktop:** 80px side margins with 32px gutters.
- **Mobile:** 20px side margins.
- **Alignment:** Use asymmetrical layouts for editorial sections, where text blocks might occupy columns 2-6 while imagery occupies 8-12, creating a sense of dynamic balance.

## Elevation & Depth
Depth is achieved through **Glassmorphism** rather than traditional shadows. This creates a "frosted amber" effect that feels like expensive perfume bottles.

- **Surfaces:** Use 60% opacity backgrounds with a `40px` backdrop-blur. 
- **Border-Stroke:** Elements are defined by thin `1px` borders in semi-transparent Gold (#C89B3C at 20% opacity) or Champagne.
- **Layers:** Objects do not "float" with shadows; they exist in stacked planes of light. Higher-elevation elements (like modals or drawers) should have a slightly lighter background tint and increased backdrop-blur.

## Shapes
In line with the 18px rounding requirement, the shape language is **Rounded**, leaning towards a "squircle" feel. This softens the high-contrast obsidian background and prevents the interface from feeling too sharp or aggressive.

- **Standard Elements:** 18px radius (buttons, input fields).
- **Cards:** 24px radius for large product or editorial cards.
- **Micro-elements:** 8px for tooltips and small tags.

## Components
- **Buttons:** Primary buttons use a solid Gold (#C89B3C) background with Ivory text in `label-caps`. Secondary buttons are "Ghost" style with an Ivory border and a glassmorphic hover effect.
- **Cards:** Utilize the glassmorphic surface (60% opacity + blur). Product cards should feature an image that subtly scales up on hover.
- **Input Fields:** Bottom-border only or fully enclosed with 18px rounding. Use Champagne (#E5C06B) for the focus state border.
- **Chips/Labels:** Small, all-caps text with generous tracking, contained within a thin-bordered pill or subtle gold-tinted background.
- **Navigation:** A floating glassmorphic bar at the top or bottom of the screen, emphasizing the cinematic "full-bleed" content behind it.
- **Progress Indicators:** Use a thin, elegant Gold line; avoid thick or industrial-looking bars.